package com.example.controller;

import org.springframework.web.bind.annotation.RequestMapping;

public class DownloadingController {
	@RequestMapping("/downloading")
	public String downloading() {
		return "downloading";
	}
}
