package com.example.controller;

import java.math.*;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {	
	
	int x = 19;
	
	@RequestMapping("/")
	public String begin() {
		return "home";
	}
	
	@RequestMapping("/home")
	public String home() {
		return "home";
	}
	
	@RequestMapping("1")
	public String one() {
		return "1";
	}
	
	private String makeOz(BigDecimal decimalOz) {
		int quarters = decimalOz.multiply(new BigDecimal("4")).setScale(0, RoundingMode.HALF_UP).intValue();
        int ounces = quarters / 4;
        int spare = quarters - (ounces * 4);
        
        
        if (spare == 0) {
        	return String.valueOf(ounces) + "oz";
        } else if (spare == 1) {
        	return String.valueOf(ounces) + " " + "&#188 oz";	
        }
        else if (spare == 2) {
        	return String.valueOf(ounces) + " " + "&#189 oz";	
        }
        else {
        	return String.valueOf(ounces) + " " +"&#190 oz";
        }
	}
	
	@RequestMapping("/downloading")
	public String downloading(@RequestParam int servings, @RequestParam int units, Model model) {
	
		if (units == 1)	{
			String unit = "g";
			int[] quantities = {100,20,75};
			for(int i=0; i<quantities.length; i++) {
		         quantities[i] = quantities[i] * servings;
		         model.addAttribute("ing_"+String.valueOf(i+1), quantities[i] + unit);
		    }
		}	else	{
			double[] quantities = {100,20,75};
			for(int i=0; i<quantities.length; i++) {
		         quantities[i] = quantities[i] * servings;
		    }
			for(int i=0; i<quantities.length; i++) {
				BigDecimal bd = BigDecimal.valueOf(quantities[i] * 0.0352733686);
			    //bd = bd.setScale(2, RoundingMode.HALF_UP);
		        model.addAttribute("ing_"+String.valueOf(i+1), makeOz(bd));
		    }
		}
		
		
		
		
		return "downloading";
	}
	
	@RequestMapping("/results")
	public String getResults(@RequestParam String keywords, Model model) {
		model.addAttribute("echo",keywords);
		
//		SELECT * FROM mytable
//		WHERE name LIKE '%keywords%'
		return "results";
	}
	

}
